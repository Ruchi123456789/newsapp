import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule, RoutingComponents } from './app-routing.module';

import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { NewsService } from './news.service';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { PostComponent } from './post/post.component';
import { NewspipePipe } from './header/latest/newspipe.pipe';


@NgModule({
  declarations: [
    AppComponent,
    RoutingComponents,
    PostComponent,
    NewspipePipe,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    AppRoutingModule

  ],
  providers: [NewsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
