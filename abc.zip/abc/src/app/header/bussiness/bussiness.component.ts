import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bussiness',
  templateUrl: './bussiness.component.html',
  styleUrls: ['./bussiness.component.css']
})
export class BussinessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
