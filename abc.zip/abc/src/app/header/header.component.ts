import { Component, OnInit, Input,  } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NewsService } from '../news.service';
import { NewsInterface } from '../news';
import { LatestComponent } from './latest/latest.component';




@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // response: any ;
  article: NewsInterface[];
  // art = '';
  constructor(private _newsservice: NewsService, private http: HttpClient) { }

  ngOnInit() {
    this._newsservice.getData()
    .subscribe((res) => {
    console.log('connected', res);
    this.article = res;

    }
   );
  }

//   show() {
//     // tslint:disable-next-line:no-unused-expression
//     this.http.get('https://newsapi.org/v2/top-headlines?language=en&apiKey=d948c11e91b04de9bbcd5bb0065a395c' + this.art)
//     .subscribe((response) => response);

// }
}
