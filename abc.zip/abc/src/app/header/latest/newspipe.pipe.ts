import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'newspipe'
})
export class NewspipePipe implements PipeTransform {

  transform(items: any[], latestNews: string): any[] {
    if (latestNews === undefined) {
      return items;
    }// else {
    //   latestNews = latestNews.toLowerCase();
    // }
    return items.filter(function(item) {
      console.log(item);
      return (item.source.name.toLowerCase().includes(latestNews.toLowerCase()) ||
      (item.source.id.toLowerCase().includes(latestNews.toLowerCase()) ||
      (item.title.toLowerCase().includes(latestNews.toLowerCase())
      )));

    });
  }

}
