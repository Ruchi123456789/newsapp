import { NewspipePipe } from './newspipe.pipe';

describe('NewspipePipe', () => {
  it('create an instance', () => {
    const pipe = new NewspipePipe();
    expect(pipe).toBeTruthy();
  });
});
