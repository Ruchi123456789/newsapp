import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NewsService } from '../../news.service';
import { NewsInterface } from '../../news';
import { NgForOf } from '@angular/common';

@Component({
  selector: 'app-latest',
  templateUrl: './latest.component.html',
  styleUrls: ['./latest.component.css']
})
export class LatestComponent implements OnInit {
 latestArticle: NewsInterface[];
 latestNews: string;

  constructor(private http: HttpClient, private _newsservice: NewsService) { }

  ngOnInit() {
    this._newsservice.getData()
    .subscribe((data) => this.latestArticle = data);
  }


}
