import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LatestComponent } from './header/latest/latest.component';
import { IndiaComponent } from './header/india/india.component';
import { WorldComponent } from './header/world/world.component';
import { BussinessComponent } from './header/bussiness/bussiness.component';
import { TechnologyComponent } from './header/technology/technology.component';
import { EntertainmentComponent } from './header/entertainment/entertainment.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes = [
  { path: 'latest' , component: LatestComponent},
  { path: 'india' , component: IndiaComponent},
  { path: 'world' , component: WorldComponent},
  { path: 'bussiness' , component: BussinessComponent},
  { path: 'technology' , component: TechnologyComponent},
  { path: 'entertainment' , component: EntertainmentComponent}
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const RoutingComponents = [HeaderComponent, LatestComponent, IndiaComponent, WorldComponent,
  BussinessComponent, TechnologyComponent, EntertainmentComponent];
