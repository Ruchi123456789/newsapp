import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NewsInterface } from './news';
import { Observable } from 'rxjs';
import { map  } from 'rxjs/operators';
import { ResponseType } from '@angular/http';
import { pipe } from '@angular/core/src/render3/pipe';

@Injectable({
  providedIn: 'root'
})
export class NewsService {

  constructor(private http: HttpClient) { }

  getData(): Observable<NewsInterface[]> {
    return this.http.get<NewsInterface[]>('https://newsapi.org/v2/top-headlines?language=en&apiKey=d948c11e91b04de9bbcd5bb0065a395c');
    }
}
